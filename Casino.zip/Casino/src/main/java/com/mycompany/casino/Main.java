package com.mycompany.casino;

public class Main {

    //Main: Punto de entrada
    //Casino: Orquestador
    //Mesa: Recurso compartido
    //Jugador: Hilo consumidor
    //Croupier: Hilo productor
    public static void main(String[] args) throws InterruptedException {
        new Casino().simular();
    }
}