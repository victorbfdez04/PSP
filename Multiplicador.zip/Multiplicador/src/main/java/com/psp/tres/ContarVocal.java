package com.psp.tres;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class ContarVocal {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new Exception("Faltan parametros. Uso: ContarVocal <fichero> <vocal>");
        }
        String nombreFichero = args[0];
        char vocal = args[1].toLowerCase().charAt(0);
        int contador = 0;
        try (BufferedReader br = new BufferedReader(new FileReader("files" + File.separator + nombreFichero))) {
            int c;
            while ((c = br.read()) != -1) {
                if (Character.toLowerCase((char) c) == vocal) {
                    contador++;
                }
            }
        }
        System.out.println(contador);
    }
}