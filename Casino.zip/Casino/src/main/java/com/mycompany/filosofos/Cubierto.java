package com.mycompany.filosofos;

import java.util.concurrent.locks.ReentrantLock;

// Recurso compartido: cada cubierto solo lo puede tener un filósofo a la vez
public class Cubierto {

    private final int id;
    private final ReentrantLock lock = new ReentrantLock(true); // lock justo: evita inanición

    public Cubierto(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void coger() {
        lock.lock();
    }

    public void soltar() {
        lock.unlock();
    }
}