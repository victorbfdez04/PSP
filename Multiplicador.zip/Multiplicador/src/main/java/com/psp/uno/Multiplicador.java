package com.psp.uno;

/**
 *
 * @author victo
 */
public class Multiplicador {
    public static int multiplicar(int n1, int n2){
        return (n1 * n2);
    }

    public static void main(String[] args){
        int n1=Integer.parseInt(args[0]);
        int n2=Integer.parseInt(args[1]);
        int suma= Multiplicador.multiplicar(n1, n2);
        System.out.println(suma);
    }
}