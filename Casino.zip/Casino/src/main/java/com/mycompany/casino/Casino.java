package com.mycompany.casino;

public class Casino {

    private static final int NUM_JUGADORES = 4;

    private final Mesa mesa;
    private final Croupier croupier;
    private final Jugador[] jugadores;

    public Casino() {
        mesa = new Mesa();
        croupier = new Croupier(mesa);
        jugadores = new Jugador[NUM_JUGADORES];
        for (int i = 0; i < NUM_JUGADORES; i++) {
            jugadores[i] = new Jugador("Jugador " + (i + 1), mesa);
        }
    }

    public void simular() throws InterruptedException {
        iniciar();
        esperarJugadores();
        detenerCroupier();
        mostrarResultados();
    }

    private void iniciar() {
        croupier.start();
        for (Jugador j : jugadores) {
            j.start();
        }
    }

    // Espera a que todos los jugadores se queden sin dinero
    private void esperarJugadores() throws InterruptedException {
        for (Jugador j : jugadores) {
            j.join();
        }
    }

    private void detenerCroupier() throws InterruptedException {
        croupier.interrupt();
        croupier.join();
    }

    private void mostrarResultados() {
        System.out.println("\n===== RESULTADO FINAL =====");
        for (Jugador j : jugadores) {
            System.out.println(j.getName() + ": " + j.getSaldo() + "€");
        }
        System.out.println("Banca: " + mesa.getSaldoBanca() + "€");
    }
}