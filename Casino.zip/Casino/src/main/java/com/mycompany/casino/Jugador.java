package com.mycompany.casino;

import java.util.Random;

public class Jugador extends Thread {

    private final Mesa mesa;
    private final Random random = new Random();
    volatile int saldo = 100;

    public Jugador(String nombre, Mesa mesa) {
        super(nombre);
        this.mesa = mesa;
    }

    public int getSaldo() {
        return saldo;
    }

    @Override
    public void run() {
        try {
            while (saldo >= 10) {
                int numero = random.nextInt(10) + 1; // del 1 al 10
                System.out.println(getName() + " apuesta 10 al " + numero);
                mesa.apostarYEsperar(this, numero);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println(getName() + " se queda sin dinero para apostar (saldo: " + saldo + "€)");
    }
}