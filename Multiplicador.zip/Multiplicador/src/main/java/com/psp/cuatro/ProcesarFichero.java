package com.psp.cuatro;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class ProcesarFichero {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new Exception("Falta el nombre del fichero. Uso: ProcesarFichero <fichero>");
        }
        long total = 0;
        try (BufferedReader br = new BufferedReader(new FileReader("files" + File.separator + args[0]))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    total = total + Integer.parseInt(linea.trim());
                }
            }
        }
        System.out.println(total);
    }
}