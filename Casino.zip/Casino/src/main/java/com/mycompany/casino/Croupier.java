package com.mycompany.casino;

import java.util.Random;

public class Croupier extends Thread {

    private final Mesa mesa;
    private final Random random = new Random();

    public Croupier(Mesa mesa) {
        super("Croupier");
        this.mesa = mesa;
    }

    @Override
    public void run() {
        while (!isInterrupted()) {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                break; // interrumpido: termina la ejecución
            }
            int numero = random.nextInt(11); // del 0 al 10
            mesa.girar(numero);
            System.out.println(">>> El croupier saca el " + numero);
        }
        System.out.println("El croupier ha sido interrumpido.");
    }
}