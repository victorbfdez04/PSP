package com.psp.seis;

import java.math.BigInteger;

public class CalcularFactorial {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new Exception("Falta el numero. Uso: CalcularFactorial <numero>");
        }
        int n = Integer.parseInt(args[0]);
        if (n < 0) {
            throw new Exception("No existe el factorial de un numero negativo: " + n);
        }
        BigInteger resultado = BigInteger.ONE;
        for (int i = 2; i <= n; i++) {
            resultado = resultado.multiply(BigInteger.valueOf(i));
        }
        System.out.println("Factorial de " + n + " = " + resultado);
    }
}