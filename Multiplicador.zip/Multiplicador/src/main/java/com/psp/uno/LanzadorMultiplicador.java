/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.psp.uno;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author victo
 */
public class LanzadorMultiplicador {
	public void lanzarMultiplicador(int n1, int n2, String fNombreSalida) throws IOException, InterruptedException {
		String clase = "com.psp.uno.Multiplicador";
		String classPath = ".;./target/classes";
		ProcessBuilder pb;
		Process process = null;
		int exitValue;
		try {
			pb = new ProcessBuilder("java", "-cp", classPath, clase, String.valueOf(n1), String.valueOf(n2));
			pb.redirectError(new File("files" + File.separator + "error_" + System.currentTimeMillis() + ".log"));
			pb.redirectOutput(new File("files" + File.separator + fNombreSalida));
			process = pb.start();
			exitValue = process.waitFor();
			if (exitValue == 0) {
				System.out.println("El proceso ha terminado correctamente. Exit Value: " + exitValue);
			} else {
				System.out.println("El proceso ha terminado con errores. Exit Value: " + exitValue);
			}
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void main(String[] args) throws Exception {
		LanzadorMultiplicador l = new LanzadorMultiplicador();
		l.lanzarMultiplicador(6, 7, "salida1.log");
		l.lanzarMultiplicador(8, 9, "salida2.log");
	}
}