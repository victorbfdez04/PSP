package com.psp.cuatro;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class LanzarProcesos {
    public void sumarContabilidades(String[] ficheros) throws Exception {
        String clase = "com.psp.cuatro.ProcesarFichero";
        String classPath = ".;./target/classes";
        ArrayList<Process> procesos = new ArrayList<Process>();

        // FASE 1: lanzar un hijo por fichero, sin esperar
        for (String fichero : ficheros) {
            ProcessBuilder pb = new ProcessBuilder("java", "-cp", classPath, clase, fichero);
            pb.redirectOutput(new File("files" + File.separator + fichero + ".res"));
            pb.redirectError(new File("files" + File.separator + fichero + ".err"));
            procesos.add(pb.start());
        }

        // FASE 2: esperar a todos
        int[] exitValues = new int[ficheros.length];
        for (int i = 0; i < ficheros.length; i++) {
            exitValues[i] = procesos.get(i).waitFor();
        }

        // FASE 3: sumar los .res de los que han terminado bien
        long total = 0;
        boolean todoCorrecto = true;
        for (int i = 0; i < ficheros.length; i++) {
            if (exitValues[i] == 0) {
                long subtotal = leerNumero("files" + File.separator + ficheros[i] + ".res");
                System.out.println(ficheros[i] + ": " + subtotal);
                total = total + subtotal;
            } else {
                todoCorrecto = false;
                System.out.println(ficheros[i] + " ha terminado con errores. Exit Value: " + exitValues[i]
                        + " (mira files" + File.separator + ficheros[i] + ".err)");
            }
        }

        // FASE 4: guardar el total en resultado_final.txt
        try (FileWriter fw = new FileWriter("files" + File.separator + "resultado_final.txt")) {
            fw.write(String.valueOf(total));
        }
        if (todoCorrecto) {
            System.out.println("Total: " + total + " (guardado en files" + File.separator + "resultado_final.txt)");
        } else {
            System.out.println("Total INCOMPLETO: " + total + " (algun fichero ha fallado)");
        }
    }

    private long leerNumero(String ruta) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea = br.readLine();
            return Long.parseLong(linea.trim());
        }
    }

    public static void main(String[] args) throws Exception {
        String[] ficheros = { "informatica.txt", "comercio.txt", "administracion.txt", "eso.txt", "bachillerato.txt" };
        LanzarProcesos lp = new LanzarProcesos();
        lp.sumarContabilidades(ficheros);
    }
}