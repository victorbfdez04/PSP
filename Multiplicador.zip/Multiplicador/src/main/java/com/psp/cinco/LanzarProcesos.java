package com.psp.cinco;

import java.io.File;
import java.util.ArrayList;

public class LanzarProcesos {
    public void buscarPalabra(String palabra) throws Exception {
        String clase = "com.psp.cinco.BuscarPalabra";
        String classPath = ".;./target/classes";
        ArrayList<Process> procesos = new ArrayList<Process>();
        ArrayList<String> nombres = new ArrayList<String>();
        File carpeta = new File("files");
        File[] contenido = carpeta.listFiles();
        for (File f : contenido) {
            String nombre = f.getName();
            if (f.isFile() && !nombre.endsWith(".res") && !nombre.endsWith(".err")) {
                ProcessBuilder pb = new ProcessBuilder("java", "-cp", classPath, clase, nombre, palabra);
                pb.redirectOutput(new File("files" + File.separator + nombre + ".res"));
                pb.redirectError(new File("files" + File.separator + nombre + ".err"));
                procesos.add(pb.start());
                nombres.add(nombre);
            }
        }
        for (int i = 0; i < procesos.size(); i++) {
            int exitValue = procesos.get(i).waitFor();
            if (exitValue == 0) {
                System.out.println(nombres.get(i) + " -> OK (resultado en " + nombres.get(i) + ".res)");
            } else {
                System.out.println(nombres.get(i) + " -> ERROR. Exit Value: " + exitValue + " (mira " + nombres.get(i) + ".err)");
            }
        }
        System.out.println("Todos los procesos han terminado.");
    }

    public static void main(String[] args) throws Exception {
        LanzarProcesos lp = new LanzarProcesos();
        lp.buscarPalabra("permission");
    }
}