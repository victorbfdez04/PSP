package com.psp.dos;

import java.io.IOException;
import java.io.InputStream;

/**
 * Lanza el proceso "cmd /C dir" y muestra por consola lo que escribe.
 * SOLO WINDOWS (cmd no existe en Linux/Mac).
 */
public class CmdDir {
    public void ejecutarDir() throws IOException, InterruptedException {
        ProcessBuilder pb;
        Process process = null;
        int exitValue;
        try {
            // cmd = interprete de comandos, /C = "ejecuta esto y termina", dir = el comando
            pb = new ProcessBuilder("cmd", "/C", "dir");
            process = pb.start();
            exitValue = process.waitFor();
            if (exitValue == 0) {
                try (InputStream is = process.getInputStream()) {
                    int c;
                    while ((c = is.read()) != -1) {
                        System.out.print((char) c);
                    }
                }
            } else {
                System.out.println("El proceso ha terminado con errores. Exit Value: " + exitValue);
                try (InputStream er = process.getErrorStream()) {
                    int c;
                    while ((c = er.read()) != -1) {
                        System.out.print((char) c);
                    }
                }
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            throw e;
        }
    }

    public static void main(String[] args) throws Exception {
        CmdDir c = new CmdDir();
        c.ejecutarDir();
    }
}