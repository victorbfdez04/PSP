package com.mycompany.casino;

import java.util.ArrayList;
import java.util.List;

// Recurso compartido: guarda el saldo de la banca y las apuestas de la ronda actual
public class Mesa {

    private static class Apuesta {
        final Jugador jugador;
        final int numero;

        Apuesta(Jugador jugador, int numero) {
            this.jugador = jugador;
            this.numero = numero;
        }
    }

    private int saldoBanca = 5000;
    private int ronda = 0;
    private final List<Apuesta> apuestas = new ArrayList<>();

    // El jugador apuesta y espera al resultado de la ronda en la que apostó
    public synchronized void apostarYEsperar(Jugador j, int numero) throws InterruptedException {
        j.saldo -= 10;
        saldoBanca += 10;
        apuestas.add(new Apuesta(j, numero));
        int rondaApuesta = ronda;
        while (ronda == rondaApuesta) {
            wait();
        }
    }

    // El croupier saca un número, paga y despierta a los jugadores
    public synchronized void girar(int numeroGanador) {
        for (Apuesta a : apuestas) {
            if (a.numero == numeroGanador) {
                int premio = Math.min(50, saldoBanca); // la banca nunca paga más de lo que tiene
                saldoBanca -= premio;
                a.jugador.saldo += premio;
            }
        }
        apuestas.clear();
        ronda++;
        notifyAll();
    }

    public synchronized int getSaldoBanca() {
        return saldoBanca;
    }
}